// src/reducers/posts.js
import { FETCH_POSTS, ADD_COMMENT, LIKE_POST } from '../actions/posts';

const initialState = {
  posts: [],
};

const postsReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_POSTS:
      return { ...state, posts: action.payload };
    case ADD_COMMENT:
      // Implement logic to add comments to the specified post
      return state;
    case LIKE_POST:
      // Implement logic to increment likes for the specified post
      return state;
    default:
      return state;
  }
};

export default postsReducer;

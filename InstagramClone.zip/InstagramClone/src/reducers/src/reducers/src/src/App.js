// src/App.js
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchPosts } from './actions/posts';

const App = () => {
  const dispatch = useDispatch();
  const posts = useSelector((state) => state.posts.posts);

  useEffect(() => {
    dispatch(fetchPosts());
  }, [dispatch]);

  return (
    <div>
      <h1>Instagram Clone</h1>
      <div>
        {posts.map((post) => (
          <div key={post.id}>
            <img src={post.imageUrl} alt={`Post ${post.id}`} />
            <button>Like</button>
            <button>Comment</button>
            {/* Render comments */}
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;

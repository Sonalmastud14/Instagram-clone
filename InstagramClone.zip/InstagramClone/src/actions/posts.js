// src/actions/posts.js
export const FETCH_POSTS = 'FETCH_POSTS';
export const ADD_COMMENT = 'ADD_COMMENT';
export const LIKE_POST = 'LIKE_POST';

export const fetchPosts = () => ({
  type: FETCH_POSTS,
  payload: [
    // Dummy data for posts
    { id: 1, imageUrl: 'https://example.com/image1.jpg', likes: 0, comments: [] },
    // Add more posts as needed
  ],
});

export const addComment = (postId, comment) => ({
  type: ADD_COMMENT,
  payload: { postId, comment },
});

export const likePost = (postId) => ({
  type: LIKE_POST,
  payload: postId,
});
